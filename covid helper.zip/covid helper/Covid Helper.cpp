#include<bits/stdc++.h>
#include<windows.h>

using namespace std;

//functions
int main();
void plasmaDonate();
void oxygenService();
bool bloodGroupValidity(string);
int meetdoctor();
int volunteer();
void admin4();
void hospitalvaccancy();
int covidhelper();
void adminUser();
void sign_up();
void sign_in();
void sign_out();
//int login();
int Parcel();
void orderItems();
void displayDetails();
void gotoxy(int x,int y);
void orderMedi();
void displayMediDetails();
int others();
int admin3();
void displayMedicine();
void addmedi();
void adminhome();
//end of functions

//struct
typedef struct orders //for ordering items.
{
    int id;
    string name;
    string location;
    string phn_num;
    string ordernum;
    string item;
    string q;

} parcel;

typedef struct ordersMedi //for ordering medicine.
{
    int id;
    string name;
    string location;
    string phn_num;
    string ordernum;
    string item;
    string q;
} medi;

typedef struct medilist //for showing medicine list.
{
    int id;
    string name;
    string price;
} list1;
//end of struct


//===============================================
//         MAIN FUNCTION starts here...
//===============================================

int main()
{
    system("CLS");
    system("color f5");
    cout<<"\n\t\t\t________________________________________________________"<<endl;
    cout<<"\n\t\t\t\t\t      COVID HELPER"<<endl;
    cout<<"\t\t\t________________________________________________________"<<endl<<endl<<endl;
    int in;

    cout<<"\t\tHere are the services we provide - "<<endl<<endl;
    cout<<"\t\t\t\tPRESS 1 : To Collect Plasma."<<endl;
    cout<<"\n\t\t\t\tPRESS 2 : To Get Oxygen Celinder."<<endl;
    cout<<"\n\t\t\t\tPRESS 3 : To Meet With Doctor."<<endl;
    cout<<"\n\t\t\t\tPRESS 4 : To Get Home parcel."<<endl;
    cout<<"\n\t\t\t\tPRESS 5 : To Be a Volunteer."<<endl;
    cout<<"\n\t\t\t\tPRESS 6 : To See Covid Bed List."<<endl;
    cout<<"\n\t\t\t\tPRESS 7 : About Us."<<endl;
    cout<<"\n\t\t\t\tPRESS 8 : To Contact Us."<<endl;
    cout<<"\n\t\t\t\tPRESS 9 : To sign-up."<<endl;
    cout<<"\n\t\t\t\tPRESS 10 : To sign-in."<<endl;
    cout<<"\n\t\t\t\tPRESS 11 : To Exit."<<endl;
    cout<<"\t\t\t\t______________________________________";
    cout<<"\n\t\t\t\tChoose your option:";
    cin>>in;

    switch (in)
    {
    case 1:
        system("CLS");
        system("color 5f");
        cout<<"\n\n\t\tPlease sign-up to use this feature.";
        cout<<"\n\n\t\t\tPress Enter to continue... ";
        cin.get();
        cin.get();
        main();
    case 2:
        system("CLS");
        system("color 5f");
        cout<<"\n\n\t\tPlease sign-up to use this feature.";
        cout<<"\n\n\t\t\tPress Enter to continue... ";
        cin.get();
        cin.get();
        main();
    case 3:
        system("CLS");
        system("color 5f");
        cout<<"\n\n\t\tPlease sign-up to use this feature.";
        cout<<"\n\n\t\t\tPress Enter to continue... ";
        cin.get();
        cin.get();
        main();
        break;

    case 4:
        system("CLS");
        system("color 5f");
        cout<<"\n\n\t\tPlease sign-up to use this feature.";
        cout<<"\n\n\t\t\tPress Enter to continue... ";
        cin.get();
        cin.get();
        main();
        break;
    case 5:
        system("CLS");
        system("color 5f");
        cout<<"\n\n\t\tPlease sign-up to use this feature.";
        cout<<"\n\n\t\t\tPress Enter to continue... ";
        cin.get();
        cin.get();
        main();
    case 6:
        system("CLS");
        system("color 5f");
        cout<<"\n\n\t\tPlease sign-up to use this feature.";
        cout<<"\n\n\t\t\tPress Enter to continue... ";
        cin.get();
        cin.get();
        main();
    case 7:
        system("CLS");
        system("color 5f");

        cout<<"\n\n\t\t Covid 19 is gradually increasing its aggressive form. Our Bangladesh has not been freed from";
        cout<<"\n\t\t this aggression of covid. Initially confined to urban areas, the deadly virus has now spread to";
        cout<<"\n\t\t rural areas. The number of victims is increasing every day. As a result, the hospitals are";
        cout<<"\n\t\t struggling to handle the patients. Due to which the people of rural areas are facing more";
        cout<<"\n\t\t difficulties. Many people are dying of shortness of breath due to not getting oxygen in time.";
        cout<<"\n\t\t Psychologically, those who suffer from covid are the most vulnerable. So, lots of psychological";
        cout<<"\n\t\t support is needed during this time. On the other hand, the victims are suffering because they";
        cout<<"\n\t\t cannot go out to buy the necessary items due to safety. This problem is more in the city. Again,";
        cout<<"\n\t\t if someone need plasma, it is not available in time. Another problem is that many people want to";
        cout<<"\n\t\t provide voluntary services to Covid victims but are unable to do so due to lack of specific";
        cout<<"\n\t\t platforms or facilities. As a result, a multi-faceted problem has arisen all over the country. And";
        cout<<"\n\t\t this problem is becoming more and more evident. And so we create an online platform";
        cout<<"\n\t\t called COVID HELPER to solve these problems mentioned by the victims of Covid.";
        cout<<"\n\n\t\t\tPress Enter to continue... ";
        cin.get();
        cin.get();
        main();
    case 8:
        system("CLS");
        cout<<"\n\t\t\t\t\t\t Contact us:"<<endl;
        cout<<"\n\t\t\t\t\t --------------------------"<<endl;

        cout<<"\n\t\t\t\t  Covid helper..." ;
        cout<<"\n\t\t\t\t  Phone number 01717171717";
        cout<<"\n\t\t\t\t  Our email address: covid_helper@gmail.com"<<endl;
        cout<<"\n\n\t\t Press enter to return home...";
        cin.get();
        cin.get();
        main();

        break;

    case 9:
        system("CLS");
        system("color 5f");
        sign_up();
        break;

    case 10:
        system("CLS");
        system("color 5f");
        adminUser();
        break;
    case 11:
        system("CLS");
        gotoxy(20,5);
        cout<<"--------------------------------------------";
        gotoxy(20,6);
        cout<<"Thanks for using COVID HELPER program...\n\n";
        gotoxy(20,7);
        cout<<"--------------------------------------------\n\n\n";

        exit(0);

    default:
        cout<<"enter valid input"<<endl;
        main();

    }
}
//===============================================
//         MAIN FUNCTION ends here...
//===============================================



//sign up function starts here.
void sign_up()
{
    system("CLS");
    ofstream file;
    file.open("usernames.txt",ios::out|ios::app);
    file.close();

    cout<<"\n\t\t\t________________________________________________________________________________"<<endl<<endl;
    cout<<"\t\t\t                                   SIGN-UP"<<endl;
    cout<<"\t\t\t________________________________________________________________________________"<<endl<<endl;

    cout<<"\n\n\t\t\tEnter Username : ";
    string user_name;
    cin.ignore();
    getline(cin,user_name);
    bool condition=false;
    for(int i=0; i<user_name.size(); i++)
    {
        if(user_name[i]==' ')
        {
            condition=true;
        }
    }
    if(condition)
    {

        cout<<"\t\t\tSpace not allowed for user name!!"<<endl;

        cout<<"\n\t\t\t1.Try again."<<endl;

        cout<<"\t\t\t2.Main-menu."<<endl;

        cout<<"\n\n\t\t\tEnter your choice: ";
        int s;
        cin>>s;
        switch(s)
        {
        case 1:
            sign_up();
            break;
        case 2:
            system("CLS");
            main();
            break;
        default:

            cout<<"\n\t\t\twrong choice!!"<<endl;

            cout<<"\n\n\t\t\tPress Enter to continue... ";
            cin.get();
            cin.get();
            main();
        }
    }
    else
    {
        ifstream file2;
        file2.open("usernames.txt");
        string existing;
        bool flag=false;
        while(file2>>existing)
        {
            if(existing==user_name)
            {
                flag=true;
            }
        }
        file2.close();
        if(flag|| user_name=="admin"|| user_name=="covid_helper")
        {

            cout<<"\t\t\tSomeone already choosen this user name, try another!"<<endl;

            cout<<"\n\t\t\t1.Try again?\n";

            cout<<"\t\t\t2.Main-menu."<<endl;
            int choice;

            cout<<"\nt\t\tChoose your option: ";
            cin>>choice;
            switch(choice)
            {
            case 1:
                sign_up();
                break;
            case 2:
                system("CLS");
                main();
            default:
            {

                cout<<"\t\t\tWrong choice!!Press Enter to continue... ";
                cin.get();
                cin.get();
                main();

            }
            }
        }
        else
        {

            cout<<"\t\t\tEnter Password: ";
            string password;
            cin>>password;


            ofstream file4;
            file4.open("usernames_and_pass.txt",ios::out|ios::app);

            file4<<user_name<<endl;
            file4<<password<<endl;
            file4.close();
            ofstream file5;
            file5.open("usernames.txt",ios::out|ios::app);
            file5<<user_name<<endl;
            file5.close();

            cout<<"\n\t\t\tSalamun Alaikum "<<user_name<<"! You are successfully registered...\n\n\t\t\tNow go to main-menu and sign-in to our system. "<<endl;

            cout<<"\n\n\t\t\tPress Enter to continue... ";
            cin.get();
            cin.get();
            main();
        }
    }
}
//sign-up function ends here.

//before sign in
void adminUser()
{
    system("CLS");
    cout<<"\n\n\n\t\tSign-in As?";
    cout<<"\n\n\n\t\t\t1) ADMIN.";
    cout<<"\n\n\n\t\t\t2) USER.";
    cout<<"\n\n\n\t\tEnter your choice: ";
    int in;
    cin>>in;
    switch(in)
    {
    case 1:
    {
        system("CLS");
        cout<<"\n\n\n\t\t\tEnter password for login: ";
        int pass;
        cin>>pass;
        if(pass==62245)
            adminhome();
        else
        {
            system("CLS");
            cout<<"\n\n\t\tWrong password!! Not Admin?";
            cout<<"\n\n\t\tPress enter to continue.";
            cin.get();
            cin.get();
            adminUser();
        }
    }
    case 2:
        sign_in();
    default:
        adminUser();
    }


}

//sign-in function starts here.
void sign_in()
{
    system("cls");

    cout<<"\n\n\t\t\t_________________________________________________________________________"<<endl;

    cout<<"\t\t\t                            SIGN-IN"<<endl;

    cout<<"\t\t\t___________________________________________________________________________"<<endl<<endl;

    cout<<"\n\t\t\tEnter username : ";
    string user_name;
    cin>>user_name;
    ifstream file;
    string  password;

    cout<<"\t\t\tEnter password: ";
    cin>>password;

    file.open("usernames_and_pass.txt");
    string nam,pass;
    bool flag=false;
    while(file>>nam)
    {
        file>>pass;
        if(nam==user_name && pass==password)
        {
            flag=true;
        }
    }
    file.close();
    if(flag)
    {

        cout<<"\n\n\t\t\tsign-in succesfully !!"<<endl;
        ofstream file2;
        file2.open("log_info.txt",ios::out|ios::app);
        file2<<user_name<<endl;
        file2.close();


        cout<<"\n\n\t\t\tPress Enter to go the home page: ";
        cin.get();
        cin.get();
        system("CLS");
        covidhelper();

    }
    else
    {

        cout<<"\n\t\t\tpassword or username maybe incorrect!"<<endl;

        cout<<"\n\t\t\t1.Try again."<<endl;

        cout<<"\t\t\t2.go to the main-menu."<<endl;

        cout<<"\n\n\t\t\tChoose your option :";
        int choice;
        cin>>choice;
        switch(choice)
        {
        case 1:
            sign_in();
            break;
        case 2:
            main();
            break;
        default:
        {

            cout<<"\n\n\t\t\tWrong choice!!Press Enter to continue: "<<endl;;
            cin.get();
            cin.get();
            main();
        }

        }
    }

}
//sign-in function ends here.

//sign-out function starts here.
void sign_out()
{
    system("cls");

    cout<<"\n\n\t\t\tAre you sure you want to sign-out?"<<endl;

    cout<<"\n\t\t\t1.YES."<<endl;

    cout<<"\t\t\t2.NO."<<endl;

    cout<<"\n\t\t\tChoose your option: ";
    char choice;
    cin>>choice;
    switch(choice)
    {
    case '1':
    {
        remove("log_info.txt");
        ofstream file2;
        file2.open("log_info.txt");
        file2.close();

        cout<<"\n\t\t\tSign-out succesfully!"<<endl;

        cout<<"\n\n\t\t\tPress Enter to continue: ";
        cin.get();
        cin.get();
        main();
    }
    break;
    case '2':
        covidhelper();
        break;
    default:
    {
        cout<<"\n\t\t\twrong choice.try again!"<<endl;
        sign_out();
    }

    }
}
//sign-out function ends here.


//===============================================
//        HOME PAGE starts here...
//===============================================
int covidhelper()
{
    system("CLS");
    system("color f5");
    cout<<setw(30)<<"\t\t\t________________________________________________________"<<endl;
    cout<<setw(30)<<"\n\t\t\t\t\t      COVID HELPER"<<endl;
    cout<<setw(30)<<"\t\t\t________________________________________________________"<<endl<<endl<<endl;
    int in;

    cout<<"\t\tHere are the services we provide - "<<endl<<endl;
    cout<<"\t\t\t\tPRESS 1 : To Collect Plajma."<<endl;
    cout<<"\n\t\t\t\tPRESS 2 : To Get Oxygen Celinder."<<endl;
    cout<<"\n\t\t\t\tPRESS 3 : To Meet With Doctor."<<endl;
    cout<<"\n\t\t\t\tPRESS 4 : To Get Home parcel."<<endl;
    cout<<"\n\t\t\t\tPRESS 5 : To Be a Volunteer."<<endl;
    cout<<"\n\t\t\t\tPRESS 6 : To See Covid Bed List."<<endl;
    cout<<"\n\t\t\t\tPRESS 7 : To Donate Us."<<endl;
    cout<<"\n\n\t\t\t\tPRESS 8 : To Sign-out."<<endl;
    cout<<"\t\t\t\t______________________________________";
    cout<<"\n\n\t\t\t\tChoose your option:";
    cin>>in;

    switch (in)
    {
    case 1:
        plasmaDonate();
    case 2:
        oxygenService();

    case 3:
        system("CLS");
        system("color 5f");
        meetdoctor();
        break;
    case 4:
        Parcel();
        break;
    case 5:
        volunteer();
        break;
    case 6:
        {
            system("cls");
            ifstream a;
            a.open("vaccancy.txt");
            string content;
            getline(a,content,',');
            cout<<content<<endl;
            a.close();
            cout<<"\n\n\t\tPress enter to continue...";
            cin.get();
            cin.get();
            covidhelper();

        }
        break;
    case 7:
      {
          system("cls");
          cout<<"\n\n\t\t\t\tDONATE US";
          cout<<"\n\t\t\t_________________";
          cout<<"\n\n\t\t\tBkash: 01823564420(personal)";
          cout<<"\n\t\t\tRefference: covid_helper";
          cout<<"\n\n\t\tPress enter to continue...";
          cin.get();
          cin.get();
          covidhelper();

      }
      break;
    case 8:
        system("CLS");
        system("color 5f");
        sign_out();
        break;

    default:
        cout<<"enter valid input"<<endl;
        covidhelper();

    }
}
//===============================================
//        HOME PAGE ends here...
//===============================================



//===============================================
//         PlASMA DONATE part starts here...
//===============================================

void plasmaDonate()
{
    system("CLS");
    int options;
    gotoxy(40,1);
    cout<<"------------------------------------------"<<endl;
    gotoxy(42,2);
    cout<<"Welcome To PLASMA DONATE Service"<<endl;
    gotoxy(40,3);
    cout<<"------------------------------------------";
    gotoxy(41,6);
    cout << "Press 1 to Donate Plasma.";
    gotoxy(41,7);
    cout << "Press 2 to see the Donor List.";
    gotoxy(41,8);
    cout << "Press 3 to return home.";
    gotoxy(41,10);
    cout<<"Enter your choice: ";
    cin >> options;
    if (options == 1)
    {
        system("CLS");
        int recoveryTime;
        gotoxy(10,3);
        cout << "How many weeks has it taken to fully recovered from Covid-19 ? ---   ";
//        cout << "\t\t\t\t\t\t\t\t\t";
        cin >> recoveryTime;
        cin.ignore();
        if (recoveryTime < 2)
        {
            cout<<"\n\n\t\tYou are not eligible for donating plasma. Plz Checkout our other services...";
            plasmaDonate();

        }
        else
        {
            string name, bloodGroup, address, phone;

            bool bgIsValid = false;
            while (!bgIsValid)
            {
                gotoxy(10,5);
                cout << "Enter your blood group in block letters : ";
                cin >> bloodGroup;
                if(bloodGroupValidity(bloodGroup))
                {
                    bgIsValid = true;
                }
                else
                {
                    cout<<"\nInvalid blood group type.\n Please enter a valid blood group.\n\n";
                }
            }
            gotoxy(10,6);
            cout << "Enter your name : ";
            getchar();
            getline(cin, name);
            gotoxy(10,7);
            cout << "Enter your address : ";
            getline(cin, address);
            gotoxy(10,8);
            cout << "Enter your phone number : ";
            getline(cin, phone);

            ofstream File;
            File.open("plasma_donor_list.txt", ios_base::app);
            if (!File)
            {
                cout << "Could not open file\n";

            }
            File << bloodGroup << "\t\t\t" << name << "\t\t\t"<< address << "\t\t\t" << phone << "\n";
            File.close();
            cin.get();
            plasmaDonate();
        }
    }
    else if (options == 2)
    {
        system("CLS");
        cout << "\n\n\n\t\t\tPress 1 to see the full list.\n";
        cout << "\n\t\t\tPress 2 to see the list for specific blood groups.\n";
        cout << "\n\n\t\t\tEnter your choice: ";

        int listOption;
        cin >> listOption;
        if (listOption == 1)
        {
            system("CLS");
            cout<<"\nBlood Group\t\tName\t\t\tAddress\t\t\tMobile\n\n";
            ifstream File;
            File.open("plasma_donor_list.txt");
            if (!File)
            {
                cout << "Could not open list\n";
                cout << "Press Enter To Continue\n";
                cin.get();
                cin.get();
                plasmaDonate();
            }
            while (File.eof() == false)
            {
                string line;
                getline(File, line,'#');
                cout <<line << "\n";
                cin.get();
                cin.get();
                plasmaDonate();
            }
        }
        else
        {
            system("CLS");
            cout << "Which Blood group are you looking for? ";
            string tBloodGroup;
            cin >> tBloodGroup;
            cout<<"\nBlood Group\t\tName\t\t\tAddress\t\t\tMobile\n\n";
            ifstream plasmaDonorListFile;
            plasmaDonorListFile.open("plasma_donor_list.txt");
            if (!plasmaDonorListFile)
            {
                cout << "Could not open list\n";
                cout << "Press Enter To Continue\n";
                cin.get();
                cin.get();
                plasmaDonate();

            }
            while (plasmaDonorListFile.eof() == false)
            {
                string line;
                getline(plasmaDonorListFile, line);
                string bloodGroup;

                bloodGroup.push_back(line[0]);
                bloodGroup.push_back(line[1]);

                if (bloodGroup[1] == 'B')
                {
                    bloodGroup.push_back(line[2]);
                }

                if (bloodGroup == tBloodGroup)
                {

                    cout <<line << "\n";


                }
            }
            plasmaDonorListFile.close();
            cin.get();
            cin.get();
            plasmaDonate();
        }
    }

    else if(options==3)
    {
        covidhelper();
    }
    else
    {
        cout << "Invalid Option\n";
        plasmaDonate();
    }
}
//===============================================
//         PlASMA DONATE part ends here...
//===============================================



//===============================================
//         OXYGEN SERVICE part starts here...
//===============================================

bool bloodGroupValidity(string bloodGroup)
{
    if (bloodGroup == "A+" || bloodGroup == "A-" || bloodGroup == "B+"
            || bloodGroup == "B-" || bloodGroup == "O+" || bloodGroup == "O-"
            || bloodGroup == "AB+" || bloodGroup == "AB-")
    {
        return true;
    }
    else return false;
}


//function for oxygen service.
void oxygenService()
{
    system("CLS");
    int option;
    cout<<"\n\t\t\t\tOxygen Cylinder Service";
    cout<<"\n\t\t\t\t________________________";
    cout << "\n\n\n\t\t Press 1: If you want to donate Oxygen Cylinder.\n\t\tPress 2: If you need Oxygen Cylinder service.";
    cout<<"\n\n\t\tPress 3: To return home.";
    cout<<"\n\n\t\tEnter your choice: ";
    cin >> option;
    int defaultOxygen;
    ifstream cylinderCountFile;
    cylinderCountFile.open("o2cylinderCount.txt");
    cylinderCountFile >> defaultOxygen;
    cylinderCountFile.close();
    if(option==3)
        covidhelper();
    if (option == 1)
    {
        system("CLS");
        int numberOfDonation;
        cout << "\n\n\t\tHow many Cylinder want to donate: ";
        cin >> numberOfDonation;
        cout << numberOfDonation << "\n\t\t  Oxygen Cylinder added." << endl;
        defaultOxygen += numberOfDonation;

        string donor_name, donor_phone;
        cout << "\n\n\t\tPlease enter your name : ";
        getchar();
        getline(cin, donor_name);
        cout << "\n\t\tEnter your phone number :";
        cin >> donor_phone;

        ofstream cylinderCountFile, o2DonorFile;
        cylinderCountFile.open("o2cylinderCount.txt");
        o2DonorFile.open("o2_donor_list.txt", ios_base::app);

        o2DonorFile << donor_name << "\t\t\t" << donor_phone << "\t\t\t\t\t" << numberOfDonation << "\n";

        cylinderCountFile << defaultOxygen;
        cylinderCountFile.close();
        o2DonorFile.close();
        cout<<"\n\n\t\tDonated Successfuly.";
        cout<<"\n\n\t\tPress enter to get back.";
        cin.get();
        cin.get();
        oxygenService();
    }
    else if (option == 2 && defaultOxygen > 0)
    {

        system("CLS");
        int oxyRequired;
        cout << "\n\n\t\t\tRemaining Oxygen Cylinder : " << defaultOxygen << endl;
        cout << "\n\n\t\tHow many Oxygen Cylinder required? : ";
        cin >> oxyRequired;
        if (oxyRequired > defaultOxygen)
        {
            cout << "\n\n\tonly " << defaultOxygen << " remaining" << endl;
            cin.get();
            cin.get();
            oxygenService();
        }
        defaultOxygen -= oxyRequired;

        string reciever_name, reciever_phone;

        cout << "\n\t\tPlease your name : ";
        getchar();
        getline(cin, reciever_name);
        cout << "\n\t\tPlease enter your phone : ";
        cin >> reciever_phone;

        ofstream o2ReciverFile;
        o2ReciverFile.open("o2_reciver_file.txt", ios_base::app);
        o2ReciverFile << reciever_name << "\t\t\t" << reciever_phone << "\t\t\t" << oxyRequired << "\n";
        cout<<"\n\n\t\t\tAs soon as possible your order will be delivered...Thank you.";
        cout << "\n\n\t\t\tnow remaining Oxygen Cylinder : " << defaultOxygen << endl;
        ofstream cylinderCountFile;
        cylinderCountFile.open("o2cylinderCount.txt");
        cylinderCountFile << defaultOxygen;
        cylinderCountFile.close();
        o2ReciverFile.close();
        cout<<"\n\n\t\tPress enter to get back.";
        cin.get();
        cin.get();
        oxygenService();
    }
    else if (option == 2 && defaultOxygen <= 0)
    {
        system("CLS");
        cout << "\n\t\t Remaining Oxygen Cylinder " << endl;
        cin.get();
        cin.get();
        oxygenService();
    }

}

admin2()
{
    system("CLS");
    cout<<"\n\n\n\t\t\tPress 1: To see DONOR list.";
    cout<<"\n\t\t\tPress 2: To see Reciever list.";
    cout<<"\n\t\t\tPress 3: To return.";
    cout<<"\n\n\t\t\tEnter your choice: ";
    int n;
    cin>>n;

    if (n == 1)
    {
        system("CLS");
        cout<<"Donor Name\t\tMobile\t\t\t\tQuantity\n\n";
        ifstream o2DonorListFile;
        o2DonorListFile.open("o2_donor_list.txt");
        if (!o2DonorListFile)
        {
            cout << "Could not open list\n";
            cout<<"\n\n\t\tPress enter to get back...";
            cin.get();
            cin.get();
            admin2();
        }
        while (o2DonorListFile.eof() == false)
        {
            string line;
            getline(o2DonorListFile, line);
            cout << line << "\n";
        }
        o2DonorListFile.close();
        cin.get();
        cin.get();
        admin2();
    }
    else if (n == 2)
    {
        system("CLS");
        cout<<"Name\t\t\tMobile\t\t\t\tQuantity\n\n";
        ifstream o2RecieveListFile;
        o2RecieveListFile.open("o2_reciver_file.txt");
        if (!o2RecieveListFile)
        {
            cout << "Could not open list\n";
            cout<<"\n\n\t\tPress enter to get back...";
            cin.get();
            cin.get();
            admin2();
        }
        while (o2RecieveListFile.eof() == false)
        {

            string line;
            getline(o2RecieveListFile, line);
            cout << line << "\n";
        }
        o2RecieveListFile.close();
        cin.get();
        cin.get();
        admin2();
    }
    else if(n==3)
        adminhome();
}

//===============================================
//        OXYGEN SERVICE part ends here.
//===============================================

void gotoxy(int x,int y) // function for moving elements.
{
    COORD c;
    c.X=x;
    c.Y=y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),c);
}

//===============================================
//        MEET DOCTOR part starts here...
//===============================================


string checkdepart(int z)
{
    switch (z)
    {
    case 1:
        return "Psycology";
        break;

    case 2:
        return "Corona unit";
        break;

    default:
        cout<<"Wrong Input";
        meetdoctor();

    }
}

shownpsyco() //showing psycology department.
{

    cout<<"\n";
    //string line;
    ifstream a;

    a.open("doctorlist.txt");

    string depart;
    int x,y,z,b,i=0;
    cout<<"_______________________________________________________________________________________________________"<<endl;
    cout << setw(5) << "ID:" << setw(15) << "DEPARTMENT" << setw(15) << "NAME" << setw(25) <<"TIMINGS(8am-8pm)"<<endl;
    cout<<"_______________________________________________________________________________________________________"<<endl<<endl;

    while  (i!=4)
    {

        a>>x;

        a.ignore();

        a>>y;
        depart=checkdepart(y);

        a.ignore();

        a >> z;

        a.ignore();

        a>>b;

        a.ignore();

        string line;
        getline(a,line,',');

        cout<<setw(4)<<x<<setw(15)<<depart<<setw(20)<<line<<setw(7)<<z<<"-"<<b<<endl;
        i++;

    }
    a.close();
}

showncunit() // showing corona unit.
{

    cout<<"\n";
    ifstream a;

    a.open("doctorlist.txt");
    string discard;
    getline(a,discard,'$');
    string depart;
    int x,y,z,b,i=0;
    cout<<"_______________________________________________________________________________________________________"<<endl;
    cout << setw(5) << "ID:" << setw(15) << "DEPARTMENT" << setw(15) << "NAME" << setw(25) <<"TIMINGS(8am-8pm)"<<endl;
    cout<<"_______________________________________________________________________________________________________"<<endl<<endl;


    while  (i!=4)
    {

        a>>x;

        a.ignore();

        a>>y;
        depart=checkdepart(y);

        a.ignore();

        a >> z;

        a.ignore();

        a>>b;

        a.ignore();

        string line;
        getline(a,line,',');

        cout<<setw(4)<<x<<setw(15)<<depart<<setw(20)<<line<<setw(7)<<z<<"-"<<b<<endl;
        i++;

    }
    a.close();
}

//function for checking appointment available or not.
bool checkavailibility(int id)
{
    fstream a ("appointments.txt");

    int number;

    a >> number;

    while(!a.eof())
    {
        if (number == id)
        {
            return false;
        }
        a >> number;

    }
    return true;
    a.close();
}

//function for making appointment.
void makeappointment(int d)
{
    bool check=false;
    while(!check)
    {
        int id;
        cout<<"Enter your desired doctor's ID number:"<<endl;
        cin>>id;

        switch(d)
        {
        case 1:
            do
            {

                if(id<=0 || id>4)
                {
                    cout<<"enter valid doctor's id number (as shown above)"<<endl;
                }
                else
                    break;
                cout<<"Enter your desired doctor's id number:";
                cin>>id;
            }
            while (id<=0 || id>4);
            break;

        case 2:
            do
            {

                if(id<=4 || id>8)
                {
                    cout<<"enter valid doctor's id number (as shown above)"<<endl;
                }
                else
                    break;

                cout<<"Enter your desired doctor's id number:";
                cin>>id;
            }
            while (id<=4 || id>8);
            break;

        }

        bool found=checkavailibility(id);

        if(!found)
        {
            cout<<"\nYour desired doctor unavailable at the moment.\nPlease make apppointment with another doctor."<<endl<<endl;
        }
        else
        {
            string data;
            ofstream a;
            a.open ("appointments.txt", ios::out|ios::app);
            a<<id<<endl;
            check=true;
            a.close();

            string name;
            char gender;
            int age;
            int mobile;

            cout<<"Enter your name: ";
            cin>>name;
            cin.ignore();
            cout<<endl<<"Enter your gender(m/f): ";
            cin>>gender;
            cin.ignore();
            cout<<endl<<"Enter your age: ";
            cin>>age;
            cout<<endl<<"Enter your phone number: ";
            cin>>mobile;
            cout<<endl;


            ofstream b;
            b.open ("patient.txt", ios::out|ios::app);
            b<<"New appointment booked for id: "<<id<<endl;
            b<<"Patients name: "<<name<<endl;
            b<<"Gender(m/f): "<<gender<<endl;
            b<<"Age: "<<age<<endl;
            b<<"Phone number: "<<mobile<<endl<<endl;
            b<<"___________________________________________"<<endl<<endl;
            b.close();
            cout<<"\nAppointment successfully done....\nPlease wait until we call you for meeting with doctor.."<<endl<<endl;
        }
        int set();
    }
}

//function for updating doctors list.
updatedoctor()
{
    fstream fin;
    fin.open("doctorlist.txt",fstream::in);

    stringstream sstr;

    string x;
    string o;
    string temp;
    cin.ignore();
    cout<<"Enter the name of Doctor which you want to replace:"<<endl;

    getline(cin,x);

    cout<<"Enter the name of new doctor:";
    getline(cin,o);


    int comma=0;
    while(! fin.eof() )
    {
        getline(fin, temp, '\n');
        if (temp.find(x) != std::string::npos)
        {
            for (int i=0; i<temp.length(); i++)
            {
                sstr<<temp[i];
                if (temp[i] == ',')
                {
                    comma++;
                }
                if (comma==4)
                {
                    break;
                }
            }
            sstr<<o<<",";
            if (temp[temp.length()-1] != ',')
            {
                sstr<<temp[temp.length()-1];
            }
            sstr<<endl;
            //cout<<o<<","<<endl;

        }
        else
        {
            sstr << temp << endl;
            //cout<<temp<<endl;
        }
    }

    fin.close();

    fstream fout;
    fin.open("doctorlist.txt", fstream::out | fstream::trunc);
    fin << sstr.str();
    //cout<< sstr.str();
}


//for admin pannel...
admin1()
{
    system("CLS");
    cout<<"\n\n\n\t\t\tPress 1: To view patient list who took appointment."<<endl;
    cout<<"\t\t\tPress 2: To update doctor."<<endl;
    cout<<"\t\t\tPress 3: To see Doctors list."<<endl;
    cout<<"\t\t\tPress 4: To return home."<<endl;
    cout<<"\t\t\t_______________________________"<<endl<<endl;
    cout<<"\t\t\tChoose your option: ";
    int op;
    cin>>op;
    if(op==1)
    {
        system("CLS");
        ifstream b;
        b.open ("patient.txt");
        string content;
        getline(b, content, '#');
        cout<<endl<<content;
        b.close();

        cout<<endl<<endl<<"press 3 to return home: ";
        int n;
        cin>>n;
        if(n==3)
        {
            system("CLS");
            admin1();
        }
    }
    else if(op==2)
    {
        system("CLS");
        updatedoctor();

        cout<<endl<<endl<<"press 3 to return home: ";
        int n;
        cin>>n;
        if(n==3)
        {
            system("CLS");
            admin1();
        }
    }
    else if(op==3)
    {
        system("CLS");
        system("color 5f");
        shownpsyco();
        showncunit();
        cout<<"\n\n\t\tPress enter to continue...";
        cin.get();
        cin.get();
        admin1();
    }
    else if(op==4)
    {
        system("CLS");
        adminhome();
    }
}

//department selection.
int sett()
{
    system("CLS");
    int choice;
    cout<<"\n\t\t\t\tChoose Department:"<<endl;
    cout<<"\n\t\t\t\t1)Psycology" ;
    cout<<"\n\t\t\t\t2)Corona unit"<<endl;
    cout<<"\n\t\t\t\t3)Return home"<<endl<<endl;
    cout<<"Enter department number: ";
    cin>>choice;

    switch(choice)
    {
    case 1:
        system("CLS");
        shownpsyco();
        break;

    case 2:
        system("CLS");
        showncunit();
        break;
    case 3:
        system("CLS");
        meetdoctor();
        break;

    default:
        cout<<"\nDepartment not present:\n";
    }
    return choice;
}


int Receptionist(int d)
{
    bool available=false;
    char ans;
    int id=90;
    cout<<endl<<"do you want to make an appointment?(y/n)"<<endl;
    char choice;
    cin>>choice;

    if(choice=='Y'||choice=='y')
    {
        makeappointment(d);
    }
    else if(choice=='N'||choice=='n')
    {
        system("CLS");
        meetdoctor();
    }

    int home;
    cout<<"Press 3: to return home - ";
    cin>>home;
    if(home==3)
    {
        system("CLS");
        meetdoctor();
    }
}


//meet doctor function starts here.
int meetdoctor()
{
    system("color f5");
    cout<<setw(30)<<"\t\t\t________________________________________________________"<<endl;
    cout<<setw(30)<<"\n\t\t\t\t\t      MEET DOCTOR"<<endl;
    cout<<setw(30)<<"\t\t\t________________________________________________________"<<endl<<endl<<endl;
    int ans;
    bool check=false;
    cout<<"\t\t\t\tPRESS 1 : To View Doctors Scedule."<<endl;
    cout<<"\n\t\t\t\tPRESS 2 : To Go To Appointment Section."<<endl;
    cout<<"\n\t\t\t\tPRESS 3 : To Go To Main Menu."<<endl;
    cout<<"\t\t\t\t______________________________________";
    cout<<"\n\n\t\t\t\tChoose your option: ";
    cin>>ans;

    int d;

    switch (ans)
    {
    case 1:
        system("CLS");
        system("color 5f");
        shownpsyco();
        showncunit();
        int home;
        cout<<endl<<"Press 3: to return home - ";
        cin>>home;
        if(home==3)
        {
            system("CLS");
            meetdoctor();
        }

        break;

    case 2:
    {
        system("CLS");
        system("color e1");
        sett();
    }
    {
        Receptionist(d);
    }
    break;

    case 3:
        system("CLS");
        covidhelper();
        break;

    default:
        cout<<"enter valid input"<<endl;

    }
    system("pause");
}
//===============================================
//        MEET DOCTOR part ends here.
//===============================================



//================================================
//        PARCEL SERVICE part starts here...
//================================================

int Parcel()
{
    system("CLS");
    system("color f5");
    gotoxy(40,1);
    cout<<"------------------------------------------"<<endl;
    gotoxy(42,2);
    cout<<"Welcome to COVID HELPER parcel service"<<endl;
    gotoxy(40,3);
    cout<<"------------------------------------------";
    gotoxy(10,5);
    cout<<"What you want to order?";
    gotoxy(15,7);
    cout<<"PRESS 1: To order MEDICINE.";
    gotoxy(15,8);
    cout<<"PRESS 2: To order other things.";
    gotoxy(15,9);
    cout<<"PRESS 3: To return home.";
    gotoxy(15,11);
    cout<<"Enter your choice: ";
    int n;
    cin>>n;
    switch (n)
    {
    case 1:
    {
        system("CLS");
        gotoxy(15,7);
        cout<<"PRESS 1: To order MEDICINE.";
        gotoxy(15,8);
        cout<<"PRESS 2: To return home.";
        gotoxy(15,10);
        cout<<"Enter your choice: ";
        int f;
        cin>>f;
        if(f==1)
        {
            displayMedicine();
            orderMedi();
        }
        else if(f==2)
            Parcel();
        break;
    }


    case 2:
    {
        others();
        break;
    }

    case 3:
    {
        covidhelper();
        break;
    }

    default:
    {
        cout<<"wrong choice...";
        Parcel();
    }
    }
}

//others function starts here.
int others()
{
    system("CLS");
    gotoxy(15,3);
    cout<<"PRESS 1: To Order items.";
    gotoxy(15,4);
    cout<<"PRESS 2: Return home.";
    gotoxy(15,6);
    cout<<"Enter your choice: ";
    int t;
    cin>>t;
    if(t==1)
        orderItems();
    else if(t==2)
        Parcel();

}
//others function ends here.

//Details function starts here.
int admin3()
{
    system("CLS");
    gotoxy(15,5);
    cout<<"PRESS 1: To see Medicine order details.";
    gotoxy(15,7);
    cout<<"PRESS 2: To see other things order details..";
    gotoxy(15,8);
    cout<<"PRESS 3: To add medicine";
    gotoxy(15,9);
    cout<<"PRESS 4: To see medicine.";
    gotoxy(15,10);
    cout<<"PRESS 5: To return home.";
    gotoxy(15,12);
    cout<<"Enter your choice: ";
    int c;
    cin>>c;

    if(c==1)
        displayMediDetails();
    else if(c==2)
        displayDetails();
    else if(c==3)
        addmedi();

    else if(c==4)
    {

        displayMedicine();
        cout<<"\n\n\t\tPress enter to continue...";
        cin.get();
        cin.get();
        admin3();
    }
    else if(c==5)
        adminhome();
}
//Details function ends here.


//Other things order  function starts here.
void orderItems()
{
    system("cls");
    ifstream idd;
    string iddd="OrdersId.txt";
    const char *pp=iddd.c_str();
    idd.open(pp);
    int aam;
    idd>>aam;
    idd.close();
    string h1="./Orders/order_list.txt";
    const char *path1 = h1.c_str();
    ofstream file;
    file.open(path1,ios::out|ios::app);
    parcel ss;
    gotoxy(40,5);
    gotoxy(40,10);
    cout<<"How many items you want to Order: ";
    int y;
    cin>>y;
    cin.ignore();
    int j=13;
    for(int i=0; i<y; i++)
    {
        gotoxy(40,++j);
        cout<<"Enter your name: ";
        getline(cin,ss.name);
        gotoxy(40,++j);
        cout<<"Enter location: ";
        getline(cin,ss.location);
        gotoxy(40,++j);
        cout<<"Enter contact number: ";
        cin>>ss.phn_num;
        cin.ignore();
        gotoxy(40,++j);
        cout<<"Enter item name: ";
        getline(cin,ss.item);
        gotoxy(40,++j);
        cout<<"Enter Quantity: ";
        getline(cin,ss.q);
        ss.id=++aam;
        file<<ss.id;
        file<<endl;
        file<<ss.name;
        file<<endl;
        file<<ss.location;
        file<<endl;
        file<<ss.phn_num;
        file<<endl;
        file<<ss.item;
        file<<endl;
        file<<ss.q;
        file<<endl;
        ++j;
    }
    ofstream fff;
    string zoom="./Orders/id.txt";
    const char *zoom1=zoom.c_str();
    fff.open(zoom1);
    fff<<(++aam);
    fff<<endl;
    fff.close();

    file.close();
    gotoxy(40,++j);
    cout<<"Ordered succesfully.";
    gotoxy(40,++j);
    cout<<"Press Enter to continue: ";
    cin.get();
    cin.get();
    Parcel();

}
//Other things order function ends here.


//Display other things order details function ends here.
void displayDetails()
{
    system("cls");

    string h1="./Orders/order_list.txt";
    const char *path1=h1.c_str();
    ifstream file;
    file.open(path1);

    parcel ss;
    int k=5;
    bool flag=false;
    while(file>>ss.id,file.ignore(),getline(file,ss.name),getline(file,ss.location),file>>ss.phn_num,file>>ss.item,file>>ss.q)
    {

        if(k==5)
        {
            flag=true;
            gotoxy(45,1);
            cout<<"-------Customer Details--------";

            gotoxy(7,3);
            cout<<"ID";

            gotoxy(17,3);
            cout<<"Customer Name";
            gotoxy(40,3);
            cout <<"location"<<endl;
            gotoxy(60,3);
            cout<<"Contact info.";
            gotoxy(80,3);
            cout<<"Product Name.";
            gotoxy(100,3);
            cout<<"Quantity.";
        }
        gotoxy(7,k);
        cout<<ss.id;
        gotoxy(17,k);
        cout<<ss.name;
        gotoxy(40,k);
        cout<<ss.location;
        gotoxy(60,k);
        cout<<ss.phn_num;
        gotoxy(80,k);
        cout<<ss.item;
        gotoxy(100,k);
        cout<<ss.q;
        k++;

    }
    file.close();
    if(!flag)
    {
        gotoxy(40,++k);
        cout<<"Order list is empty.";
    }
    gotoxy(50,++k);

    cout<<"Press Enter to continue... ";
    cin.get();
    cin.get();
    admin3();
}

//Display other things order details function ends here.


//Medicine order function starts here.
void orderMedi()
{
    ifstream idd;
    string iddd="./OrdersMedi/id.txt";
    const char *pp=iddd.c_str();
    idd.open(pp);
    int aam;
    idd>>aam;
    idd.close();
    string h1="./OrdersMedi/order_list.txt";
    const char *path1 = h1.c_str();
    ofstream file;
    file.open(path1,ios::out|ios::app);
    medi ss;
    gotoxy(40,5);
    gotoxy(10,21);
    cout<<"How many Medicine do you want to Order: ";
    int y;
    cin>>y;
    cin.ignore();
    int j=32;
    for(int i=0; i<y; i++)
    {
        gotoxy(10,++j);
        cout<<"Enter your name: ";
        getline(cin,ss.name);
        gotoxy(10,++j);
        cout<<"Enter location: ";
        getline(cin,ss.location);
        gotoxy(10,++j);
        cout<<"Enter contact number: ";
        cin>>ss.phn_num;
        cin.ignore();
        gotoxy(10,++j);
        cout<<"Enter Medicine name: ";
        getline(cin,ss.item);
        gotoxy(10,++j);
        cout<<"Enter Quantity: ";
        getline(cin,ss.q);
        ss.id=++aam;
        file<<ss.id;
        file<<endl;
        file<<ss.name;
        file<<endl;
        file<<ss.location;
        file<<endl;
        file<<ss.phn_num;
        file<<endl;
        file<<ss.item;
        file<<endl;
        file<<ss.q;
        file<<endl;
        ++j;
    }
    ofstream fff;
    string zoom="./OrdersMedi/id.txt";
    const char *zoom1=zoom.c_str();
    fff.open(zoom1);
    fff<<(++aam);
    fff<<endl;
    fff.close();

    file.close();
    gotoxy(40,++j);
    cout<<"Ordered succesfully.";
    gotoxy(40,++j);
    cout<<"Press Enter to continue: ";
    cin.get();
    cin.get();
    Parcel();

}
//medicine order function ends here.

//Display medicine order details function ends here.
void displayMediDetails()
{
    system("cls");

    string h1="./OrdersMedi/order_list.txt";
    const char *path1=h1.c_str();
    ifstream file;
    file.open(path1);

    medi ss;
    int k=5;
    bool flag=false;
    while(file>>ss.id,file.ignore(),getline(file,ss.name),getline(file,ss.location),file>>ss.phn_num,file>>ss.item,file>>ss.q)
    {

        if(k==5)
        {
            flag=true;
            gotoxy(45,1);
            cout<<"-------Customer Details--------";

            gotoxy(7,3);
            cout<<"ID";

            gotoxy(17,3);
            cout<<"Customer Name";
            gotoxy(40,3);
            cout <<"location"<<endl;
            gotoxy(60,3);
            cout<<"Contact info.";
            gotoxy(80,3);
            cout<<"Medicine Name.";
            gotoxy(100,3);
            cout<<"Quantity.";
        }
        gotoxy(7,k);
        cout<<ss.id;
        gotoxy(17,k);
        cout<<ss.name;
        gotoxy(40,k);
        cout<<ss.location;
        gotoxy(60,k);
        cout<<ss.phn_num;
        gotoxy(80,k);
        cout<<ss.item;
        gotoxy(100,k);
        cout<<ss.q;
        k++;

    }
    file.close();
    if(!flag)
    {
        gotoxy(40,++k);
        cout<<"Order list is empty.";
    }
    gotoxy(50,++k);

    cout<<"Press Enter to continue... ";
    cin.get();
    cin.get();
    admin3();
}
//Display medicine order details function ends here.

//Display medicine function starts here.
void displayMedicine()
{
    system("cls");

    string h1="./medilist/medi_list1.txt";
    const char *path1=h1.c_str();
    ifstream file;
    file.open(path1);

    list1 ss;
    int k=5;
    bool flag=false;
    while(file>>ss.id,file.ignore(),getline(file,ss.name),getline(file,ss.price))
    {

        if(k==5)
        {
            flag=true;
            gotoxy(45,1);
            cout<<"-------Medicine List--------";

            gotoxy(7,3);
            cout<<"ID";

            gotoxy(17,3);
            cout<<"Medicine Name";
            gotoxy(40,3);
            cout <<"Price(tk)"<<endl;

        }
        gotoxy(7,k);
        cout<<ss.id;
        gotoxy(17,k);
        cout<<ss.name;
        gotoxy(40,k);
        cout<<ss.price;
        k++;

    }
    file.close();
    if(!flag)
    {
        gotoxy(40,++k);
        cout<<"list is empty.";
    }

}
//Display medicine function ends here.

//add medicine function starts here.
void addmedi()
{
    system("cls");
    ifstream idd;
    string iddd="./medilist/id.txt";
    const char *pp=iddd.c_str();
    idd.open(pp);
    int aam;
    idd>>aam;
    idd.close();
    string h1="./medilist/medi_list1.txt";
    const char *path1 = h1.c_str();
    ofstream file;
    file.open(path1,ios::out|ios::app);
    list1 ss;
    gotoxy(40,5);
    gotoxy(40,10);
    cout<<"How many items you want to add: ";
    int y;
    cin>>y;
    cin.ignore();
    int j=13;
    for(int i=0; i<y; i++)
    {
        gotoxy(40,++j);
        cout<<"Enter Medicine name: ";
        getline(cin,ss.name);
        gotoxy(40,++j);
        cout<<"Enter Price: ";
        getline(cin,ss.price);

        ss.id=++aam;
        file<<ss.id;
        file<<endl;
        file<<ss.name;
        file<<endl;
        file<<ss.price;
        file<<endl;

        ++j;
    }
    ofstream fff;
    string zoom="./medilist/id.txt";
    const char *zoom1=zoom.c_str();
    fff.open(zoom1);
    fff<<(++aam);
    fff<<endl;
    fff.close();

    file.close();
    gotoxy(40,++j);
    cout<<"Added succesfully.";
    gotoxy(40,++j);
    cout<<"Press Enter to continue: ";
    cin.get();
    cin.get();
    adminhome();
}
//add medicine function ends here.

//===============================================
//         PARCEL SERVICE ends here...
//===============================================



//===============================================
//         VOLUNTEER part starts here...
//===============================================

int volunteer()
{
    system("CLS");
    cout<<"\t\t______________________________________"<<endl;
    cout<<"\t\t\tVolunteer Registration"<<endl;
    cout<<"\t\t______________________________________"<<endl<<endl;

    string name,gender,age,address, email,mobile;

    cout<<"enter your name: ";
    cin>>name;
    cout<<"enter your gender(m/f): ";
    cin>>gender;
    cout<<"enter your age: ";
    cin>>age;
    cout<<"enter your address: ";
    cin>>address;
    cout<<"enter your email: ";
    cin>>email;
    cout<<"enter your phone number: ";
    cin>>mobile;
    cout<<endl<<endl<<"Registered Successfuly";
    cout<<endl<<endl<<"Press enter to return home...";

    string data;
    ofstream a;
    a.open ("reginfo.txt", ios::out|ios::app);
    a<<"Name: "<<name<<endl;
    a<<"Gender: "<<gender<<endl;
    a<<"Age: "<<age<<endl;
    a<<"Address: "<<address<<endl;
    a<<"Email: "<<email<<endl;
    a<<"Mobile: "<<mobile<<endl;
    a<<"-----------------------------\n";
    a.close();
    cin.get();
    cin.get();
    covidhelper();
}

void admin4()
{
    system("CLS");
    cout<<"\n\t\t\t\tVolunteer Details";
    cout<<"\n\t\t\t-------------------------";
    ifstream b;
    b.open ("reginfo.txt");
    string content;
    getline(b, content, '#');
    cout<<endl<<content;
    b.close();
    cout<<"\n\n\t\tPress enter to get back...";
    cin.get();
    cin.get();
    adminhome();

}
//===============================================
//         VOLUNTEER part ends here...
//===============================================



//===============================================
//         ADMINS FUNCTION starts here...
//===============================================
void adminhome()
{
    system("CLS");
    cout<<setw(30)<<"\t\t\t________________________________________________________"<<endl;
    cout<<setw(30)<<"\n\t\t\t\t\t      Admin Pannel"<<endl;
    cout<<setw(30)<<"\t\t\t________________________________________________________"<<endl<<endl<<endl;
    int n;
    cout<<"\t\t\t\tPRESS 1 : To go to MEET DOCTOR admin pannel."<<endl;
    cout<<"\n\t\t\t\tPRESS 2 : To go to OXYGEN SERVICE admin pannel."<<endl;
    cout<<"\n\t\t\t\tPRESS 3 : To go to PARCEL SERVICE admin pannel."<<endl;
    cout<<"\n\t\t\t\tPRESS 4 : To see VOLUNTEER Details."<<endl;
    cout<<"\n\t\t\t\tPRESS 5 : To sign-out."<<endl;
    cout<<"\n\t\t\t\t----------------------------------------"<<endl;
    cout<<"\n\n\t\t\t\tEnter your choice: ";
    cin>>n;

    switch(n)
    {
    case 1:
        system("CLS");
        admin1();
        break;
    case 2:
        system("CLS");
        admin2();
        break;
    case 3:
        system("CLS");
        admin3();
        break;
    case 4:
        system("CLS");
        admin4();
        break;

    case 5:
        system("CLS");
        sign_out();
        break;
    default:
        adminhome();
        break;
    }

}
//Admin pannel ends here.


